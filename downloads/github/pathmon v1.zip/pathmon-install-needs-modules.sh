pip install prettytable
pip install scapy
pip install requests
pip install folium

clear

echo ### НУЖНЫЕ МОДУЛИ УСТАНОВЛЕНЫ ###